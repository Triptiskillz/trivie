# import random
import os

from flask import abort, Flask, jsonify, request
from werkzeug.exceptions import HTTPException
from sqlalchemy.sql.expression import func
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS
import random

from models import Category, Question, setup_db

QUESTIONS_PER_PAGE = 10


def create_app():
    """
    Creates and sets up a Flask application
    :return: Flask application
    """
    app = Flask(__name__)
    setup_db(app)

    CORS(app, resources={r'/': {'origins': '*'}})

    @app.after_request
    def set_headers(response):
        """
        Intercept response to add 'Access-Control-Allow' headers
        :param response: HTTP Response
        :return: Modified HTTP Response
        """
        response.headers.add('Access-Control-Allow-Headers',
                             'Content-Type, Authorization, true')
        response.headers.add('Access-Control-Allow-Methods',
                             'GET, PATCH, POST, DELETE, OPTIONS')
        return response

    @app.route('/categories', methods=['GET'])
    def get_all_categories():
        """
        Creates a dictionary of all categories
        :return: All categories
        """
        categories = {}
        for category in Category.query.all():
            categories[category.id] = category.type
            if(len(categories)==0):
                abort(404)
        return jsonify({
            'success': True,
            'categories': categories
       })



    @app.route('/questions', methods=['GET'])
    def get_questions():
        """
        Get all questions, categories and total questions from database
        :return: Questions, categories and total questions
        """
        categories = {}
        for category in Category.query.all():
            categories[category.id] = category.type
        questions = [question.format() for question in Question.query.all()]
        page = int(request.args.get('page', '0'))
        upper_limit = page * 10
        lower_limit = upper_limit - 10
        if (len(questions)==0):
            abort(404)
        return jsonify({
            'success': True,
            'questions': questions[
                         lower_limit:upper_limit] if page else questions,
            'total_questions': len(questions),
            'categories': categories
        })

    @app.route('/questions/<int:question_id>', methods=['DELETE'])
    def delete_question(question_id):
        """
        Delete a question using question id
        :param question_id: Id of the question to be deleted
        :return: Id of the question that has been deleted
        """
       try:
        question = Question.query.get(question_id)
        if not question:
            return abort(404, f'No question found with id: {question_id}')
        question.delete()
        return jsonify({
            'success':True,
            'deleted': question_id
        })
        except:
            abort(422)

    @app.route('/questions', methods=['POST'])
    def post_question():
        """
        Adds a question to database
        :return: The question that is added
        """
        question = request.json.get('question')
        answer = request.json.get('answer')
        category = request.json.get('category')
        difficulty = request.json.get('difficulty')
        if not (question and answer and category and difficulty):
            return abort(400,
                         'Required question object keys missing from request '
                         'body')
        question_entry = Question(question, answer, category, difficulty)
        question_entry.insert()
        return jsonify({
            'succes': True,
            'question': question_entry.format(),
            'total_questions': len(questions)
        })

    @app.route('/search', methods=['POST'])
    def search():
        """
        Search for questions using the search term
        :return: Searched questions and total questions
        """
        search_term = request.json.get('searchTerm', '')
        questions = [question.format() for question in Question.query.all() if
                     re.search(search_term, question.question, re.IGNORECASE)]
        return jsonify({
            'questions': questions,
            'total_questions': len(questions)
        })

    @app.route('/categories/<int:category_id>/questions', methods=['GET'])
    def get_questions_by_category(id):
        """
        Gets questions from database and filters them based on category
        :param category_id: The category for which questions are to be filtered
        :return: Filtered questions, total questions and current category
        """
        if not id:
            return abort(400, 'Invalid category id')
        questions = [question.format() for question in
                     Question.query.filter(Question.category == id)]
        return jsonify({
            'success':True,
            'questions': questions,
            'total_questions': len(questions),
            'current_category': id
        })

    @app.route('/quizzes', methods=['POST'])
    def get_quiz_questions():
        """
        Gets question for quiz
        :return: Uniques quiz question or None
        """
        previous = request.json.get('questions')
        quiz_category = request.json.get('quiz_category')
        if not quiz_category:
            return abort(400, 'Required keys missing from request body')
        category_id = int(quiz_category.get('id'))
        questions = Question.query.filter(
            Question.category == category_id,
            ~Question.id.in_(questions)) if category_id else \
            Question.query.filter(~Question.id.in_(questions))
        question = questions.order_by(func.random()).first()
        if not question:
            return jsonify({
                'success':True
            })
        return jsonify({
            'success':True,
            'question': question.format()
        })


# error handlers

    @app.errorhandler(404)
    def not_found(error):
        return jsonify({
            "success": False,
            "error": 404,
            "message": "resource not found"
        }), 404

    @app.errorhandler(422)
    def unprocessable(error):
        return jsonify({
            "success": False,
            "error": 422,
            "message": "unprocessable"
        }), 422

    @app.errorhandler(400)
    def bad_request(error):
        return jsonify({
            "success": False,
            "error": 400,
            "message": "bad request"
        }), 400
    @app.errorhandler(405)
    def  not_found(error):
        return jsonify({
            "success": False,
            "error": 405,
            "message": "method not allowed"
        }), 405

    return app
